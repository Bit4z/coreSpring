package com.stereoTypeAnnotation;

public class Teacher {

}
