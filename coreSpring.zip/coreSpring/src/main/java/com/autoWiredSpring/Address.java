package com.autoWiredSpring;

public class Address {

}
