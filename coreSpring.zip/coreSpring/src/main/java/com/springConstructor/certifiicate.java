package com.springConstructor;

public class certifiicate {
 String name;

public certifiicate(String name) {
	super();
	this.name = name;
}

@Override
public String toString() {
	// TODO Auto-generated method stub
	return this.name;
}
}
