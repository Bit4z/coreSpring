package com.standAloneCollections;

public class Student {

}
