package com.removeXmlSpring;

public class Samosa {
	public void display()
	{
		System.out.println("My samosa price is litle bit high..");
	}

}
